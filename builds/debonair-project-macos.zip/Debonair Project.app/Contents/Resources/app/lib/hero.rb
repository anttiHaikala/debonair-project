class Hero < Entity

  attr_reader :role, :species, :trait, :age, :name, :exhaustion, :hunger, :sleep_deprivation, :insanity, :carried_items

  def initialize(x, y)
    super(x, y)
    @kind = :pc
    @role = Hero.roles.sample
    @species = Hero.species.sample
    @trait = Hero.traits.sample
    @age = Hero.age.sample
    @name = 'Jaakko'
    @exhaustion = 0.2 # 0.0 = totally rested, 1.0 = totally exhausted
    @hunger = 0.2 # 0.0 = satiated, 1.0 = starving
    @sleep_deprivation = 0.2 # 0.0 = well-rested, 1.0 = totally sleep-deprived
    @insanity = 0.0 # 0.0 = sane, 1.0 = totally insane
    @stress = 0.0 # 0.0 = calm, 1.0 = totally stressed
    @carried_items = []
  end

  def self.roles
    [
      :archeologist, # maps and artifacts
      :cleric, # holiness
      :detective, # investigation and clues
      :druid, # spells and nature
      :mage, # classic spellcaster
      :monk, # martial arts and spirituality
      :ninja, # stealth and combat
      :rogue, # agility and trickery
      :samurai, # combat and honor
      :thief, # stealth and deception
      :tourist, # camera and confidence
      :warrior, # strength and bravery
    ]
  end

  def self.species
    [
      :human,
      :elf,
      :dwarf,
      :orc,
      :gnome,
      :halfling,
      :dark_elf,
      :goblin,
      :troll,
      :duck # glorantha style
    ]
  end

  def self.age
    [
      :teen,
      :adult,
      :elder
    ]
  end

  def self.traits
    [
      :none,
      :undead,
      :mutant,
      :cyborg,      
      :alien,
      :robot,
      :vampire,
      :werewolf,
      :zombie,
      :demon,
      :angel
    ]
  end

  def vision_range
    range = 7
    if @age == :elder
      range -= 2
    end
    if @species == :dwarf || @species == :gnome
      range -= 1
    end
    if @species == :elf || @species == :dark_elf
      range += 1
    end
    return range
  end

  def walking_speed
    seconds_per_tile = 1.0
    if @age == :elder
      seconds_per_tile += 0.5
    end
    if @trait == :robot
      seconds_per_tile += 0.1
    end
    if @trait == :cyborg 
      seconds_per_tile -= 0.3
    end
    if @species == :duck
      seconds_per_tile += 0.3
    end
    return seconds_per_tile
  end

  def pickup_speed
    seconds_per_pickup = 1.0 # seconds to pick up items
    if @species == :halfling || @species == :gnome
      seconds_per_pickup -= 0.3
    end
    return seconds_per_pickup
  end

  def stealth_range
    range = 10 # smaller is stealthier
    if @role == :ninja || @role == :thief
      range -= 3
    end
    if @species == :halfling || @species == :gnome
      range -= 3
    end
    return range
  end

  def c
    [0, 4]
  end

  def take_action args
    # hero is controlled by player, so no AI here
  end 

  def pick_up_item(item, level)
    @carried_items << item
    level.items.delete(item)
    item.x = nil
    item.y = nil
    item.level = nil
    printf "Picked up item: %s\n" % item.kind.to_s
  end

  def has_item?(item_kind)
    @carried_items.each do |item|
      return true if item.kind == item_kind
    end
    return false
  end

end