class Dungeon
  attr_accessor :levels
  def initialize
    @levels = []
  end
end